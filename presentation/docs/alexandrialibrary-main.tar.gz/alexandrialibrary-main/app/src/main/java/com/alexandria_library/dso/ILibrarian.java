package com.alexandria_library.dso;

public interface ILibrarian extends IUser{
}
