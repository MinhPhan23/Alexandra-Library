package com.alexandria_library.data.hsqldb;

public class PersistenceException extends RuntimeException{
    public PersistenceException(final Exception cause) {super(cause);}
}
