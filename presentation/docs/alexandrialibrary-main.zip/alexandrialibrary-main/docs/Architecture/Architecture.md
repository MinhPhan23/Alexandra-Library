# Architecture

## Iteration 1

![Iteration1 Architecture](I1Architecture.jpg)

## Iteration 2

![Iteration1 Architecture](I2Architecture.jpg)

## Iteration 3

![Iteration1 Architecture](I3Architecture.png)