1. Register
   1. Click CREATE ACCOUNT
   2. Click on the "Librarian" button on the top right
   3. Type in username “Admin”
   4. Type in password "1234"
   5. Confirm password by typing in "1234" on the third line
   6. Clink on the arrow button below
2. Log in
   1. Click on the "Librarian" button on the top right
   2. Type in username “Admin”
   3. Type in password “1234”
   4. Click on the arrow on the right
3. Add a new book
   1. Clink on the "ADD NEW BOOK" button on the left side panel
   2. Type in title "Hamlet"
   3. Type in author "William Shakespeare"
   4. Type in tags "Literature,Revenge,Play"
   5. Type in genres "Tragedy,Drama"
   6. Type in date "July 26, 1602"
   7. Click on the arrow left to the text fields
   8. Make sure you can see the book on the top of the list on the screen
4. Log out
    1. Click on the "ACCOUNT" button on the bottom left
    2. Click on the "Log out"
5. Log in
   1. Click on the "Librarian" button on the top right
   2. Type in username “Admin”
   3. Type in password “1234”
   4. Click on the arrow on the right
6. Verify the book was for sure added
   1. Check if the book you added is still on the library list

