1. Log in
   1. Type in username "Carlo" in the username input
   2. Type in password "123" in the password input
   3. Click log-in
2. Try filter with no selected filters
   1. Click the filter button next to the search bar at the top of the page
   2. Verify that the Filter UI appears (a grey box in the body with a sidebar to the right with checkboxes)
   3. Click the Filter button in the sidebar to the right
   4. Verify that 5 books appear in the grey box
3. Try filter with some filters
   1. Click on the checkbox labelled "Love" under the Tags section of the filter sidebar
   2. Click on the checkbox labelled "Contemporary" under the Genre section of the filter sidebar
   3. Click the Filter button in the sidebar to the right
   4. Verify that only one book appears in the grey box ("The Fault in Our Stars")