1. Register
    1. Click CREATE ACCOUNT
    2. Click on the "Librarian" button on the top right
    3. Type in username “Librarian”
    4. Type in password "1234"
    5. Confirm password by typing in "1234" on the third line
    6. Clink on the arrow button below
2. Log in
    1. Click on the "Librarian" button on the top right
    2. Type in username “Librarian”
    3. Type in password “1234”
    4. Click on the arrow on the right
3. Check the type of the account
    1. Make sure you see "ADD NEW BOOK" on the left side panel
4. Log out
    1. Click on the "ACCOUNT" button on the bottom left
    2. Click on the "Log out"

