1. Log in
   1. Register a new account username: "Tester" password: "test"
   2. Log in with the new credentials
2. Add the books into the default lists
   1. show how the three default lists, all, in progress, and finished are all empty
   2. switch to the library view and add 1 book to each default list
   3. try to add one of the books twice to show that the user cant add duplicates
3. Verify the correct books were added
   1. go to all list and check to see the right book was added to it
   2. go to in progress list and check to see the right book was added to it
   3. go to finished list and check to see the right book was added to it