1. Log in
    1. Type in username “Minh”
    2. Type in password “123”
    3. Click log-in
2. Search a book by name
   1. Click on the search bar at the top
   2. Type in bookname “”
   3. Click the search icon
   4. Book should show up as result
3. Search a new book by author name
   1. Click on the search bar again
   2. Delete old string
   3. Enter an author name
   4. The new book with that author should show it
