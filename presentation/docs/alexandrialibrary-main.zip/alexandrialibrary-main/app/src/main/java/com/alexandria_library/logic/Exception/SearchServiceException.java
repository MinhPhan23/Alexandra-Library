package com.alexandria_library.logic.Exception;

public class SearchServiceException extends Exception {
    public SearchServiceException(String message) {
        super(message);
    }
}
