package com.alexandria_library.dso;

public interface IBooklist {

    public String getName();

    public String getDesc();

    public void setName(String name);

    public void setDesc(String desc);
}
