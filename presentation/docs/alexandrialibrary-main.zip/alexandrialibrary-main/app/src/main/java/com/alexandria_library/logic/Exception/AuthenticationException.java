package com.alexandria_library.logic.Exception;

public class AuthenticationException extends Exception{
        public AuthenticationException(String message) {
            super(message);
        }
}
