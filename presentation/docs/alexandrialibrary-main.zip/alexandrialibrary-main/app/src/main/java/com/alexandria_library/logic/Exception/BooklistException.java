package com.alexandria_library.logic.Exception;

public class BooklistException extends Exception {
    public BooklistException(String message) {
        super(message);
    }
}
