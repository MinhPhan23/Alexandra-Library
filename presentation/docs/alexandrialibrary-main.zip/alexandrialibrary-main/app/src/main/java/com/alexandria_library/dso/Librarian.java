package com.alexandria_library.dso;

public class Librarian extends User implements ILibrarian {

    public Librarian(String userName, String password, int id){
        super(userName, password, id);
    }

}
